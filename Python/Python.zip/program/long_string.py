print '''This is a very long string.
It continues here.
And it's not over yet.
"Hello, world!"
Still here.'''