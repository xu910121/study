print "Hello, world!"

name = raw_input("What is your name?\n")
print "Hello,"+ name + "!"

raw_input("Press <enter> to exits")