#coding:UTF-8
name = input("What is your name? 此处因为是使用的input，所以输入时要带上引号\n")
print "Hello, " + name + "!"

name = raw_input("What is your name?\n")
print "Hello, " + name + "!"

print input("Enter a number:")
print raw_input("Enter a number:")